const access = (permitted) => {
  return (req, res, next) => {
    if (permitted.includes(req.role)) {
      next();
    } else {
      res.status(403).send({ msg: "Access Denied" });
    }
    // next();
  };
};

module.exports = {
  access,
}